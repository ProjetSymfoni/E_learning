<?php

namespace App\Entity;

use App\Repository\EtudiantRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=EtudiantRepository::class)
 */
class Etudiant
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $nom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $prenom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $email;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $login;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $password;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $niveau;

    /**
     * @ORM\OneToMany(targetEntity=Administrateur::class, mappedBy="etudiant")
     */
    private $administrateurs;

    /**
     * @ORM\OneToMany(targetEntity=Supportcours::class, mappedBy="etudiant")
     */
    private $supportcours;

    /**
     * @ORM\OneToMany(targetEntity=Notes::class, mappedBy="etudiant")
     */
    private $notes;

    /**
     * @ORM\ManyToMany(targetEntity=Forum::class, mappedBy="etudiant")
     */
    private $forums;

    /**
     * @ORM\OneToMany(targetEntity=Boitededialogue::class, mappedBy="etudiant")
     */
    private $boitededialogues;

    public function __construct()
    {
        $this->administrateurs = new ArrayCollection();
        $this->supportcours = new ArrayCollection();
        $this->notes = new ArrayCollection();
        $this->forums = new ArrayCollection();
        $this->boitededialogues = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->prenom;
    }

    public function setPrenom(string $prenom): self
    {
        $this->prenom = $prenom;

        return $this;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function setEmail(string $email): self
    {
        $this->email = $email;

        return $this;
    }

    public function getLogin(): ?string
    {
        return $this->login;
    }

    public function setLogin(string $login): self
    {
        $this->login = $login;

        return $this;
    }

    public function getPassword(): ?string
    {
        return $this->password;
    }

    public function setPassword(string $password): self
    {
        $this->password = $password;

        return $this;
    }

    public function getNiveau(): ?string
    {
        return $this->niveau;
    }

    public function setNiveau(string $niveau): self
    {
        $this->niveau = $niveau;

        return $this;
    }

    /**
     * @return Collection|Administrateur[]
     */
    public function getAdministrateurs(): Collection
    {
        return $this->administrateurs;
    }

    public function addAdministrateur(Administrateur $administrateur): self
    {
        if (!$this->administrateurs->contains($administrateur)) {
            $this->administrateurs[] = $administrateur;
            $administrateur->setEtudiant($this);
        }

        return $this;
    }

    public function removeAdministrateur(Administrateur $administrateur): self
    {
        if ($this->administrateurs->removeElement($administrateur)) {
            // set the owning side to null (unless already changed)
            if ($administrateur->getEtudiant() === $this) {
                $administrateur->setEtudiant(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|Supportcours[]
     */
    public function getSupportcours(): Collection
    {
        return $this->supportcours;
    }

    public function addSupportcour(Supportcours $supportcour): self
    {
        if (!$this->supportcours->contains($supportcour)) {
            $this->supportcours[] = $supportcour;
            $supportcour->setEtudiant($this);
        }

        return $this;
    }

    public function removeSupportcour(Supportcours $supportcour): self
    {
        if ($this->supportcours->removeElement($supportcour)) {
            // set the owning side to null (unless already changed)
            if ($supportcour->getEtudiant() === $this) {
                $supportcour->setEtudiant(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|Notes[]
     */
    public function getNotes(): Collection
    {
        return $this->notes;
    }

    public function addNote(Notes $note): self
    {
        if (!$this->notes->contains($note)) {
            $this->notes[] = $note;
            $note->setEtudiant($this);
        }

        return $this;
    }

    public function removeNote(Notes $note): self
    {
        if ($this->notes->removeElement($note)) {
            // set the owning side to null (unless already changed)
            if ($note->getEtudiant() === $this) {
                $note->setEtudiant(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|Forum[]
     */
    public function getForums(): Collection
    {
        return $this->forums;
    }

    public function addForum(Forum $forum): self
    {
        if (!$this->forums->contains($forum)) {
            $this->forums[] = $forum;
            $forum->addEtudiant($this);
        }

        return $this;
    }

    public function removeForum(Forum $forum): self
    {
        if ($this->forums->removeElement($forum)) {
            $forum->removeEtudiant($this);
        }

        return $this;
    }

    /**
     * @return Collection|Boitededialogue[]
     */
    public function getBoitededialogues(): Collection
    {
        return $this->boitededialogues;
    }

    public function addBoitededialogue(Boitededialogue $boitededialogue): self
    {
        if (!$this->boitededialogues->contains($boitededialogue)) {
            $this->boitededialogues[] = $boitededialogue;
            $boitededialogue->setEtudiant($this);
        }

        return $this;
    }

    public function removeBoitededialogue(Boitededialogue $boitededialogue): self
    {
        if ($this->boitededialogues->removeElement($boitededialogue)) {
            // set the owning side to null (unless already changed)
            if ($boitededialogue->getEtudiant() === $this) {
                $boitededialogue->setEtudiant(null);
            }
        }

        return $this;
    }
}
