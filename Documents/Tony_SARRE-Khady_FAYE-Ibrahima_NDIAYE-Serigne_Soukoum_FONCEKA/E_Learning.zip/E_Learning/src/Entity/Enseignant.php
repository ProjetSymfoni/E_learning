<?php

namespace App\Entity;

use App\Repository\EnseignantRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=EnseignantRepository::class)
 */
class Enseignant
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $nom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $prenom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $login;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $password;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $email;

    /**
     * @ORM\ManyToOne(targetEntity=Stockage::class, inversedBy="enseignants")
     */
    private $stockage;

    /**
     * @ORM\OneToMany(targetEntity=Administrateur::class, mappedBy="enseignant")
     */
    private $administrateurs;

    /**
     * @ORM\OneToMany(targetEntity=Boitededialogue::class, mappedBy="enseignant")
     */
    private $boitededialogues;

    public function __construct()
    {
        $this->administrateurs = new ArrayCollection();
        $this->boitededialogues = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->prenom;
    }

    public function setPrenom(string $prenom): self
    {
        $this->prenom = $prenom;

        return $this;
    }

    public function getLogin(): ?string
    {
        return $this->login;
    }

    public function setLogin(string $login): self
    {
        $this->login = $login;

        return $this;
    }

    public function getPassword(): ?string
    {
        return $this->password;
    }

    public function setPassword(string $password): self
    {
        $this->password = $password;

        return $this;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function setEmail(string $email): self
    {
        $this->email = $email;

        return $this;
    }

    public function getStockage(): ?Stockage
    {
        return $this->stockage;
    }

    public function setStockage(?Stockage $stockage): self
    {
        $this->stockage = $stockage;

        return $this;
    }

    /**
     * @return Collection|Administrateur[]
     */
    public function getAdministrateurs(): Collection
    {
        return $this->administrateurs;
    }

    public function addAdministrateur(Administrateur $administrateur): self
    {
        if (!$this->administrateurs->contains($administrateur)) {
            $this->administrateurs[] = $administrateur;
            $administrateur->setEnseignant($this);
        }

        return $this;
    }

    public function removeAdministrateur(Administrateur $administrateur): self
    {
        if ($this->administrateurs->removeElement($administrateur)) {
            // set the owning side to null (unless already changed)
            if ($administrateur->getEnseignant() === $this) {
                $administrateur->setEnseignant(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|Boitededialogue[]
     */
    public function getBoitededialogues(): Collection
    {
        return $this->boitededialogues;
    }

    public function addBoitededialogue(Boitededialogue $boitededialogue): self
    {
        if (!$this->boitededialogues->contains($boitededialogue)) {
            $this->boitededialogues[] = $boitededialogue;
            $boitededialogue->setEnseignant($this);
        }

        return $this;
    }

    public function removeBoitededialogue(Boitededialogue $boitededialogue): self
    {
        if ($this->boitededialogues->removeElement($boitededialogue)) {
            // set the owning side to null (unless already changed)
            if ($boitededialogue->getEnseignant() === $this) {
                $boitededialogue->setEnseignant(null);
            }
        }

        return $this;
    }
}
