<?php

namespace App\Entity;

use App\Repository\StockageRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=StockageRepository::class)
 */
class Stockage
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="integer")
     */
    private $liste_etudiant;

    /**
     * @ORM\Column(type="date")
     */
    private $openingtime;

    /**
     * @ORM\Column(type="date")
     */
    private $deadline;

    /**
     * @ORM\OneToMany(targetEntity=Enseignant::class, mappedBy="stockage")
     */
    private $enseignants;

    public function __construct()
    {
        $this->enseignants = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getListeEtudiant(): ?int
    {
        return $this->liste_etudiant;
    }

    public function setListeEtudiant(int $liste_etudiant): self
    {
        $this->liste_etudiant = $liste_etudiant;

        return $this;
    }

    public function getOpeningtime(): ?\DateTimeInterface
    {
        return $this->openingtime;
    }

    public function setOpeningtime(\DateTimeInterface $openingtime): self
    {
        $this->openingtime = $openingtime;

        return $this;
    }

    public function getDeadline(): ?\DateTimeInterface
    {
        return $this->deadline;
    }

    public function setDeadline(\DateTimeInterface $deadline): self
    {
        $this->deadline = $deadline;

        return $this;
    }

    /**
     * @return Collection|Enseignant[]
     */
    public function getEnseignants(): Collection
    {
        return $this->enseignants;
    }

    public function addEnseignant(Enseignant $enseignant): self
    {
        if (!$this->enseignants->contains($enseignant)) {
            $this->enseignants[] = $enseignant;
            $enseignant->setStockage($this);
        }

        return $this;
    }

    public function removeEnseignant(Enseignant $enseignant): self
    {
        if ($this->enseignants->removeElement($enseignant)) {
            // set the owning side to null (unless already changed)
            if ($enseignant->getStockage() === $this) {
                $enseignant->setStockage(null);
            }
        }

        return $this;
    }
}
