<?php

namespace App\Entity;

use App\Repository\CreneauRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=CreneauRepository::class)
 */
class Creneau
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="date")
     */
    private $openingtime;

    /**
     * @ORM\Column(type="date")
     */
    private $deadline;

    /**
     * @ORM\OneToMany(targetEntity=Emploidutemps::class, mappedBy="creneau")
     */
    private $emploidutemps;

    public function __construct()
    {
        $this->emploidutemps = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getOpeningtime(): ?\DateTimeInterface
    {
        return $this->openingtime;
    }

    public function setOpeningtime(\DateTimeInterface $openingtime): self
    {
        $this->openingtime = $openingtime;

        return $this;
    }

    public function getDeadline(): ?\DateTimeInterface
    {
        return $this->deadline;
    }

    public function setDeadline(\DateTimeInterface $deadline): self
    {
        $this->deadline = $deadline;

        return $this;
    }

    /**
     * @return Collection|Emploidutemps[]
     */
    public function getEmploidutemps(): Collection
    {
        return $this->emploidutemps;
    }

    public function addEmploidutemp(Emploidutemps $emploidutemp): self
    {
        if (!$this->emploidutemps->contains($emploidutemp)) {
            $this->emploidutemps[] = $emploidutemp;
            $emploidutemp->setCreneau($this);
        }

        return $this;
    }

    public function removeEmploidutemp(Emploidutemps $emploidutemp): self
    {
        if ($this->emploidutemps->removeElement($emploidutemp)) {
            // set the owning side to null (unless already changed)
            if ($emploidutemp->getCreneau() === $this) {
                $emploidutemp->setCreneau(null);
            }
        }

        return $this;
    }
}
