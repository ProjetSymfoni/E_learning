<?php

namespace App\Controller\Admin;

use App\Entity\Etudiant;
use App\Entity\Enseignant;
use App\Entity\Boitededialogue;
use App\Entity\Creneau;
use App\Entity\Emploidutemps;
use App\Entity\Forum;
use App\Entity\Matiere;
use App\Entity\Notes;
use App\Entity\Utilisateur;
use EasyCorp\Bundle\EasyAdminBundle\Config\Dashboard;
use EasyCorp\Bundle\EasyAdminBundle\Config\MenuItem;
use EasyCorp\Bundle\EasyAdminBundle\Controller\AbstractDashboardController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class DashboardController extends AbstractDashboardController
{
    /**
     * @Route("/admin", name="admin")
     */
    public function index(): Response
    {
        return $this->render('bundles/EasyAdminBundle/welcome.html.twig',[
            'user'=>[]
        ]);
        //return parent::index();
    }

    public function configureDashboard(): Dashboard
    {
        return Dashboard::new()
            ->setTitle('E Learning');
    }

    public function configureMenuItems(): iterable
    {
        yield MenuItem::linktoDashboard('Dashboard', 'fa fa-home');
        yield MenuItem::linkToCrud('Etudiant', 'fa fa-user', Etudiant::class);
        yield MenuItem::linkToCrud('Enseignant', 'fa fa-user', Enseignant::class);
        yield MenuItem::linkToCrud('Boitededialogue', 'fa fa-user', Boitededialogue::class);
        yield MenuItem::linkToCrud('Creneau', 'fa fa-user', Creneau::class);
        yield MenuItem::linkToCrud('Emploidutemps', 'fa fa-user', Emploidutemps::class);
        yield MenuItem::linkToCrud('Forum', 'fa fa-user', Forum::class);
        yield MenuItem::linkToCrud('Matiere', 'fa fa-user', Matiere::class);
        yield MenuItem::linkToCrud('Notes', 'fa fa-user', Notes::class);
        yield MenuItem::linkToCrud('Utilisateur', 'fa fa-user', Utilisateur::class);
        // yield MenuItem::linkToCrud('The Label', 'fas fa-list', EntityClass::class);
    }
}
