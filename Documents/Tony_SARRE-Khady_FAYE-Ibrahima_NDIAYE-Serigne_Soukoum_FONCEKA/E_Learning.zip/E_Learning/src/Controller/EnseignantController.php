<?php

namespace App\Controller;

use App\Entity\Supportcours;
use App\Form\SupportType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class EnseignantController extends AbstractController
{
    /**
     * @Route("/enseignant", name="enseignant")
     * @param Request
     * return Response
     */
    public function index(): Response
    {
        return $this->render('enseignant/index.html.twig', [
            'controller_name' => 'EnseignantController',
        ]);
    }
    
    /**
     * @Route("/ajoutersupport", name="ajoutersupport")
     * @param Request
     * return Response
     */
    public function ajoutersupport(Request $request):Response
    {
        $support = new Supportcours();
        $form = $this->createform(SupportType::class, $support);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid() )
        {
            $em = $this->getDoctrine()->getManager();
            $em->persist($support);
            $em->flush();
            return $this->redirectToRoute('enseignant/index.html.twig');
        }
        return $this->render('ajoutersupport.html.twig',[
        "form"=>$form->createView()
        ]);
    }
}
