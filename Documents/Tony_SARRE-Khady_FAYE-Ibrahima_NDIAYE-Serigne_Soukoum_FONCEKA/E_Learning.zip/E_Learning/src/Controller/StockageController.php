<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class StockageController extends AbstractController
{
    /**
     * @Route("/stockage", name="stockage")
     */
    public function index(): Response
    {
        return $this->render('stockage/index.html.twig', [
            'controller_name' => 'StockageController',
        ]);
    }
}
