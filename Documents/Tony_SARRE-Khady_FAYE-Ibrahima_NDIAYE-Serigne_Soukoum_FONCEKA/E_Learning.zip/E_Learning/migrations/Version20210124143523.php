<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210124143523 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE administrateur (id INT AUTO_INCREMENT NOT NULL, etudiant_id INT DEFAULT NULL, enseignant_id INT DEFAULT NULL, nom VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, email VARCHAR(255) NOT NULL, login VARCHAR(255) NOT NULL, password VARCHAR(255) NOT NULL, INDEX IDX_32EB52E8DDEAB1A3 (etudiant_id), INDEX IDX_32EB52E8E455FCC0 (enseignant_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE boitededialogue (id INT AUTO_INCREMENT NOT NULL, etudiant_id INT DEFAULT NULL, enseignant_id INT DEFAULT NULL, INDEX IDX_32DB3FBCDDEAB1A3 (etudiant_id), INDEX IDX_32DB3FBCE455FCC0 (enseignant_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE creneau (id INT AUTO_INCREMENT NOT NULL, openingtime DATE NOT NULL, deadline DATE NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE emploidutemps (id INT AUTO_INCREMENT NOT NULL, matiere_id INT DEFAULT NULL, creneau_id INT DEFAULT NULL, INDEX IDX_5152B578F46CD258 (matiere_id), INDEX IDX_5152B5787D0729A9 (creneau_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE enseignant (id INT AUTO_INCREMENT NOT NULL, stockage_id INT DEFAULT NULL, nom VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, login VARCHAR(255) NOT NULL, password VARCHAR(255) NOT NULL, email VARCHAR(255) NOT NULL, INDEX IDX_81A72FA1DAA83D7F (stockage_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE etudiant (id INT AUTO_INCREMENT NOT NULL, nom VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, email VARCHAR(255) NOT NULL, login VARCHAR(255) NOT NULL, password VARCHAR(255) NOT NULL, niveau VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE forum (id INT AUTO_INCREMENT NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE forum_etudiant (forum_id INT NOT NULL, etudiant_id INT NOT NULL, INDEX IDX_568DAF0429CCBAD0 (forum_id), INDEX IDX_568DAF04DDEAB1A3 (etudiant_id), PRIMARY KEY(forum_id, etudiant_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE matiere (id INT AUTO_INCREMENT NOT NULL, nom VARCHAR(255) NOT NULL, semestre INT NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE notes (id INT AUTO_INCREMENT NOT NULL, etudiant_id INT DEFAULT NULL, matiere_id INT DEFAULT NULL, INDEX IDX_11BA68CDDEAB1A3 (etudiant_id), INDEX IDX_11BA68CF46CD258 (matiere_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE stockage (id INT AUTO_INCREMENT NOT NULL, liste_etudiant INT NOT NULL, openingtime DATE NOT NULL, deadline DATE NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE supportcours (id INT AUTO_INCREMENT NOT NULL, etudiant_id INT DEFAULT NULL, matiere_id INT DEFAULT NULL, nom VARCHAR(255) NOT NULL, INDEX IDX_78F96AD4DDEAB1A3 (etudiant_id), INDEX IDX_78F96AD4F46CD258 (matiere_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE administrateur ADD CONSTRAINT FK_32EB52E8DDEAB1A3 FOREIGN KEY (etudiant_id) REFERENCES etudiant (id)');
        $this->addSql('ALTER TABLE administrateur ADD CONSTRAINT FK_32EB52E8E455FCC0 FOREIGN KEY (enseignant_id) REFERENCES enseignant (id)');
        $this->addSql('ALTER TABLE boitededialogue ADD CONSTRAINT FK_32DB3FBCDDEAB1A3 FOREIGN KEY (etudiant_id) REFERENCES etudiant (id)');
        $this->addSql('ALTER TABLE boitededialogue ADD CONSTRAINT FK_32DB3FBCE455FCC0 FOREIGN KEY (enseignant_id) REFERENCES enseignant (id)');
        $this->addSql('ALTER TABLE emploidutemps ADD CONSTRAINT FK_5152B578F46CD258 FOREIGN KEY (matiere_id) REFERENCES matiere (id)');
        $this->addSql('ALTER TABLE emploidutemps ADD CONSTRAINT FK_5152B5787D0729A9 FOREIGN KEY (creneau_id) REFERENCES creneau (id)');
        $this->addSql('ALTER TABLE enseignant ADD CONSTRAINT FK_81A72FA1DAA83D7F FOREIGN KEY (stockage_id) REFERENCES stockage (id)');
        $this->addSql('ALTER TABLE forum_etudiant ADD CONSTRAINT FK_568DAF0429CCBAD0 FOREIGN KEY (forum_id) REFERENCES forum (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE forum_etudiant ADD CONSTRAINT FK_568DAF04DDEAB1A3 FOREIGN KEY (etudiant_id) REFERENCES etudiant (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE notes ADD CONSTRAINT FK_11BA68CDDEAB1A3 FOREIGN KEY (etudiant_id) REFERENCES etudiant (id)');
        $this->addSql('ALTER TABLE notes ADD CONSTRAINT FK_11BA68CF46CD258 FOREIGN KEY (matiere_id) REFERENCES matiere (id)');
        $this->addSql('ALTER TABLE supportcours ADD CONSTRAINT FK_78F96AD4DDEAB1A3 FOREIGN KEY (etudiant_id) REFERENCES etudiant (id)');
        $this->addSql('ALTER TABLE supportcours ADD CONSTRAINT FK_78F96AD4F46CD258 FOREIGN KEY (matiere_id) REFERENCES matiere (id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE emploidutemps DROP FOREIGN KEY FK_5152B5787D0729A9');
        $this->addSql('ALTER TABLE administrateur DROP FOREIGN KEY FK_32EB52E8E455FCC0');
        $this->addSql('ALTER TABLE boitededialogue DROP FOREIGN KEY FK_32DB3FBCE455FCC0');
        $this->addSql('ALTER TABLE administrateur DROP FOREIGN KEY FK_32EB52E8DDEAB1A3');
        $this->addSql('ALTER TABLE boitededialogue DROP FOREIGN KEY FK_32DB3FBCDDEAB1A3');
        $this->addSql('ALTER TABLE forum_etudiant DROP FOREIGN KEY FK_568DAF04DDEAB1A3');
        $this->addSql('ALTER TABLE notes DROP FOREIGN KEY FK_11BA68CDDEAB1A3');
        $this->addSql('ALTER TABLE supportcours DROP FOREIGN KEY FK_78F96AD4DDEAB1A3');
        $this->addSql('ALTER TABLE forum_etudiant DROP FOREIGN KEY FK_568DAF0429CCBAD0');
        $this->addSql('ALTER TABLE emploidutemps DROP FOREIGN KEY FK_5152B578F46CD258');
        $this->addSql('ALTER TABLE notes DROP FOREIGN KEY FK_11BA68CF46CD258');
        $this->addSql('ALTER TABLE supportcours DROP FOREIGN KEY FK_78F96AD4F46CD258');
        $this->addSql('ALTER TABLE enseignant DROP FOREIGN KEY FK_81A72FA1DAA83D7F');
        $this->addSql('DROP TABLE administrateur');
        $this->addSql('DROP TABLE boitededialogue');
        $this->addSql('DROP TABLE creneau');
        $this->addSql('DROP TABLE emploidutemps');
        $this->addSql('DROP TABLE enseignant');
        $this->addSql('DROP TABLE etudiant');
        $this->addSql('DROP TABLE forum');
        $this->addSql('DROP TABLE forum_etudiant');
        $this->addSql('DROP TABLE matiere');
        $this->addSql('DROP TABLE notes');
        $this->addSql('DROP TABLE stockage');
        $this->addSql('DROP TABLE supportcours');
    }
}
